# Decosk API with Spring boot!

Decosk는 책상 위의 작은 세상을 나타냅니다.
여러분의 집, 회사, 각종 책상이 있을 수 있는 모든 곳에서 여러분의 책상에 놓일 데코를 만나보실 수 있습니다.

# Functional Specification

- Users

# License

Apache 2.0 License.
