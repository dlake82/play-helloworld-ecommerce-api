package com.saysimple.decosk

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DecoskApplication

fun main(args: Array<String>) {
	runApplication<DecoskApplication>(*args)
}
